'use strict';

var filters = angular.module("testeFilters", []);

filters.filter("startFrom", function () {
    return function(input, start) {
        start = +start;
        return input ? input.slice(start) : input;
    }
});