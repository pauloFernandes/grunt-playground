'use strict';

var testeControllers = angular.module("testeControllers", ["ui.bootstrap"]);

testeControllers.controller("testeGridController", ["$scope", "$http",
    function($scope, $http) {
        $http.get("data/teste_grid.json").success(function(data) {
            $scope.data = data;
            
            $scope.totalItems   = $scope.data.length;
            $scope.currentPage  = 1;
            $scope.itemsPerPage = 5;

            $scope.showInputItemsPerPage = true;
        });

        $scope.buttons = [
            {
                label: "salvar",
                method: "salvar()"
            },
            {
                label: "excluir",
                method: "excluir()"
            }
        ]
        
        $scope.salvar = function () {
            alert("botao de salvar.");
        };

        $scope.excluir = function () {
            alert("botao de excluir.");
        };

    }]);