'use strict';

var teste = angular.module("testeApp", ["testeControllers", "testeFilters", "testeDirectives"]);

teste.config(["$routeProvider", function($routeProvider) {
    $routeProvider.
      when("/teste", {
        templateUrl: "partials/grid.html",
        controller: "testeGridController"
      }).
      otherwise({
        redirectTo: "/teste"
      })
}]);