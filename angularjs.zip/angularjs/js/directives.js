'use strict';

var directives = angular.module("testeDirectives", []);

directives.directive('testeGrid', [
    function() {
        return {
            restrict: "EA",
            templateUrl: "partials/teste-grid.html",
            link: function(scope, element, attrs) {
            }
        };
    }]);